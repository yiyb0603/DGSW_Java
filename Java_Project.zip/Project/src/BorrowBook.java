import java.util.Scanner;

public class BorrowBook {
	public void borrow() {
		int count = 0;
		Scanner sc = new Scanner(System.in);
		HowToUse use = new HowToUse();
		ShowingBooks books = new ShowingBooks();

		System.out.print("빌리실 책의 이름을 입력하세요 : ");
		String bookName = sc.nextLine();
		String title = bookName.substring(0, 2);

		if (title.equals("영어"))
			books.englishBooks(bookName);

		else if (title.equals("수학"))
			books.mathBooks(bookName);

		else if (title.equals("과학"))
			books.scienceBooks(bookName);

		else if (title.equals("프로"))
			books.programmingBooks(bookName);

		else {
			System.out.println("일치하는 도서가 없습니다.");
			System.out.println();
			use.libraryHelp1();
		}

		System.out.println(bookName + " 책을 대출 하시겠습니까? Y / N");
		String answer = sc.nextLine();

		if (answer != null) {
			if (answer.equals("Y")) {
				System.out.println();
				System.out.println("책이 대출 되었습니다. 책을 빌린 날 7일 이후 까지 반납하십시오.");
				System.out.println();
				borrowList(bookName);
				count++;
				use.libraryHelp1();

				if (count > 3) {
					System.out.println("책 대출이 불가능 합니다.");
					use.libraryHelp1();
				}
			}

			else if (answer.equals("N")) {
				System.out.println("책 대출이 취소되었습니다.");
			}

		} else {
			System.out.println("ㅇㅇㅇ");
		}
	}

	public void borrowList(String bookName) {
		int borrowCount = 1;
		HowToUse use = new HowToUse();
		String[] arr = new String[3];

		System.out.print("현재 빌린 책 목록: ");

		for (int i = 0; i < borrowCount; i++) {
			arr[0 + i] = bookName;
			System.out.println(arr[i]);
		}
	}
}