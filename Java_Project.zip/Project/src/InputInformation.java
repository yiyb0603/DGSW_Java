import java.util.Scanner;

public class InputInformation {
	Scanner sc = new Scanner(System.in);
	String name;
	String date;
	String phoneNumber;

	public void inputInfo() {
		System.out.print("이름을 입력해주세요: ");
		name = sc.nextLine();
		
		System.out.print("생년월일을 입력해주세요 (xxxx-xx-xx 형식) : ");
		date = sc.nextLine();
		
		System.out.print("전화번호를 입력해주세요 (010-xxxx-xxxx 형식) : ");
		phoneNumber = sc.nextLine();

		System.out.println();
		System.out.println("====회원 정보====");
		System.out.println("회원 이름: " + name);
		System.out.println("회원의 생년월일: " + date);
		System.out.println("회원의 전화번호: " + phoneNumber);
		System.out.println();
	}
}