import java.util.Scanner;

public class HowToUse {
	public void libraryHelp1() {
		int choice;
		Scanner sc = new Scanner(System.in);
		ShowingBooks books = new ShowingBooks();

		while (true) {
			System.out.println("[0] 메인화면으로 가기");
			System.out.println("[1] 과학 도서보기");
			System.out.println("[2] 수학 도서보기");
			System.out.println("[3] 영어 도서보기");
			System.out.println("[4] 프로그래밍 도서 보기");

			System.out.println("번호를 입력하세요: ");
			choice = sc.nextInt();

			if (choice == 0) {
				while (true) {
					System.out.println("도서관에 오신걸 환영합니다!");
					System.out.println("원하는것을 보려면 해당 번호를 눌러주세요!");
					System.out.println("[0]: 종료하기");
					System.out.println("[1]: 도서 목록보기");
					System.out.println("[2]: 도서 대출하기");
					System.out.println("[3]: 대출 목록보기");
					System.out.println("[4]: 회원 정보보기");
					System.out.println();
					System.out.print("번호를 입력하세요: ");
					choice = sc.nextInt();

					if (choice == 0) {
						System.out.println("프로그램을 종료합니다.");
						System.exit(0);
					}

					else if (choice == 1) {
						System.out.println("[0] 메인화면으로 가기");
						System.out.println("[1] 과학 도서보기");
						System.out.println("[2] 수학 도서보기");
						System.out.println("[3] 영어 도서보기");
						System.out.println("[4] 프로그래밍 도서 보기");

						System.out.println("번호를 입력하세요 : ");
						choice = sc.nextInt();

						switch (choice) {
						case 1:
							books.scienceBooks();
							break;
						case 2:
							books.mathBooks();
							break;
						case 3:
							books.englishBooks();
							break;
						case 4:
							books.programmingBooks();
							break;
						default:
							System.out.println();
							System.out.println("다시 입력해주세요.");
						}
					}

					else if (choice == 2) {
						libraryHelp2();
					}

					else if (choice == 3) {
						libraryHelp3();
					}
					
					else if(choice == 4)
						libraryHelp4();
				}
			}

			switch (choice) {
			case 1:
				books.scienceBooks();
				break;
			case 2:
				books.mathBooks();
				break;
			case 3:
				books.englishBooks();
				break;
			case 4:
				books.programmingBooks();
				break;
			default:
				System.out.println();
				System.out.println("다시 입력해주세요.");
			}
		}
	}

	public void libraryHelp2() {
		int bookCategory;
		Scanner sc = new Scanner(System.in);
		BorrowBook Borrow = new BorrowBook();
		ShowingBooks books = new ShowingBooks();

		while (true) {
			System.out.println();
			System.out.println("[0]: 프로그램 종료하기");
			System.out.println("[1]: 과학 도서보기 및 대출");
			System.out.println("[2]: 수학 도서보기 및 대출");
			System.out.println("[3]: 영어 도서보기 및 대출");
			System.out.println("[4]: 프로그래밍 도서 보기 및 대출");

			System.out.print("빌리실 책의 카테고리 번호를 입력하세요 : ");
			bookCategory = sc.nextInt();

			if (bookCategory == 0) {
				System.out.println("프로그램 종료");
				System.exit(0);
			}

			switch (bookCategory) {
			case 1:
				books.scienceBooks();
				Borrow.borrow();
				break;

			case 2:
				books.mathBooks();
				Borrow.borrow();
				break;

			case 3:
				books.englishBooks();
				Borrow.borrow();
				break;

			case 4:
				books.programmingBooks();
				Borrow.borrow();
				break;
			}
		}
	}

	public void libraryHelp3() {
		BorrowBook Borrow = new BorrowBook();
		Borrow.borrowList("아직 목록이 없습니다.");
		System.out.println();
		libraryHelp1();
	}
	
	public void libraryHelp4() {
		InputInformation info = new InputInformation();
		info.inputInfo();
		libraryHelp1();
	}
}