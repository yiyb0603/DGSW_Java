public class ShowingBooks {
	public void scienceBooks() {
		String[] science = new String[30];
		for (int i = 0; i < science.length; i++) {
			science[i] = "과학책 " + 0 + (i + 1);
		}

		System.out.println("------- 책 목록 -------");

		for (String i : science) {
			System.out.println(i);
		}
		System.out.println();
	}

	public void scienceBooks(String scienceBook) {
		String[] science = new String[30];
		HowToUse use = new HowToUse();
		BorrowBook borrow = new BorrowBook();
		boolean hasSameBook = false;
		for (int i = 0; i < science.length; i++) {
			science[i] = "과학책 " + 0 + (i + 1);
		}

		for (String i : science) {
			if (i.equals(scienceBook)) {
				hasSameBook = true;
				break;
			} 
		}
	}

	public void mathBooks() {
		String[] math = new String[30];

		for (int i = 0; i < math.length; i++) {
			math[i] = "수학책 " + 0 + (i + 1);
		}

		System.out.println("------- 책 목록 -------");

		for (String i : math) {
			System.out.println(i);
		}
		System.out.println();
	}

	public void mathBooks(String mathBook) {
		String[] math = new String[30];
		HowToUse use = new HowToUse();
		boolean hasSameBook = false;

		for (int i = 0; i < math.length; i++) {
			math[i] = "수학책 " + 0 + (i + 1);
		}

		for (String i : math) {
			if (i.equals(mathBook)) {
				hasSameBook = true;
				break;
			}

			else if (hasSameBook == false) {
				System.out.println("일치하는 도서가 없습니다.");
				use.libraryHelp2();
			}
		}
	}

	public void englishBooks() {
		String[] english = new String[30];
		for (int i = 0; i < english.length; i++) {
			english[i] = "영어책 " + 0 + (i + 1);
		}

		System.out.println("------- 책 목록 -------");

		for (String i : english) {
			System.out.println(i);
		}
		System.out.println();
	}

	public void englishBooks(String englishBook) {
		String[] english = new String[30];
		HowToUse use = new HowToUse();
		BorrowBook book = new BorrowBook();
		boolean hasSameBook = false;

		for (int i = 0; i < english.length; i++) {
			english[i] = "영어책 " + 0 + (i + 1);
		}

		for (String i : english) {
			if (i.equals(englishBook)) {
				hasSameBook = true;
				break;
			}

			else if (hasSameBook == false) {
				System.out.println("일치하는 도서가 없습니다.");
				use.libraryHelp2();
			}
		}
	}

	public void programmingBooks() {
		String[] programming = new String[30];
		for (int i = 0; i < programming.length; i++) {
			programming[i] = "프로그래밍책 " + 0 + (i + 1);
		}

		System.out.println("------- 책 목록 -------");

		for (String i : programming) {
			System.out.println(i);
		}
		System.out.println();
	}

	public void programmingBooks(String programmingBook) {
		String[] programming = new String[30];
		HowToUse use = new HowToUse();
		boolean hasSameBook = false;

		for (int i = 0; i < programming.length; i++) {
			programming[i] = "프로그래밍책 " + 0 + (i + 1);
		}

		for (String i : programming) {
			if (i.equals(programming)) {
				hasSameBook = true;
				break;
			}

			else if (hasSameBook == false) {
				System.out.println("일치하는 도서가 없습니다.");
				use.libraryHelp2();
			}
		}
	}
}