import java.util.Scanner;

public class MainLibrary {
	public static void main(String[] args) {
		int choice;
		HowToUse use = new HowToUse();
		Scanner sc = new Scanner(System.in);
		ShowingBooks books = new ShowingBooks();
		InputInformation info = new InputInformation();

		info.inputInfo();

		System.out.println();
		System.out.println("도서관에 오신걸 환영합니다!");
		System.out.println("원하는것을 보시려면 해당 번호를 눌러주세요!");
		System.out.println("[0]: 종료하기");
		System.out.println("[1]: 도서 목록보기");
		System.out.println("[2]: 도서 대출하기");
		System.out.println("[3]: 도서 대출 목록보기");
		System.out.println("[4]: 회원 정보 보기");
		System.out.println();
		System.out.print("번호를 입력하세요: ");
		choice = sc.nextInt();

		if (choice == 0) {
			System.out.println("프로그램을 종료합니다.");
			System.exit(0);
		}

		else if (choice == 1) {
			use.libraryHelp1();
		}

		else if (choice == 2) {
			use.libraryHelp2();
		}

		else if (choice == 3) {
			use.libraryHelp3();
		}

		else if (choice == 4) {
			use.libraryHelp4();
		}

		else {
			System.out.println("다시 입력해주세요.");
			while (choice != 1 || choice != 2 || choice != 3 || choice != 4) {
				System.out.println();
				System.out.println("도서관에 오신걸 환영합니다!");
				System.out.println("원하는것을 보시려면 해당 번호를 눌러주세요!");
				System.out.println("[0]: 종료하기");
				System.out.println("[1]: 도서 목록보기");
				System.out.println("[2]: 도서 대출하기");
				System.out.println("[3]: 대출 목록보기");
				System.out.println("[4]: 회원 정보보기");
				System.out.println();
				System.out.print("번호를 입력하세요: ");
				choice = sc.nextInt();

				if (choice == 1)
					use.libraryHelp1();

				else if (choice == 2)
					use.libraryHelp2();

				else if (choice == 3)
					use.libraryHelp3();

				else if (choice == 4)
					use.libraryHelp4();
			}
		}
	}
}